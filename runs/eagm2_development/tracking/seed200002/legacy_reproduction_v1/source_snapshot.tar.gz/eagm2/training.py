"""Common-data experimental trainer with explicit objective adaptations."""
import copy,time
import numpy as np
import torch
from torch import nn
from eagm2.runtime import measured,seed_all,stream_seed
from eagm2.models import ExecutionWorldModel,capacity_matched_width
from eagm2.prior import observable_step
from eagm2.rollout import imagined,tensor
from eagm2.gradients import calibration_loss
from eagm2.baselines import QCritic,paml_loss,vagram_loss
from training.rollout import actor
from training.reward import reward_torch

METHODS={
 'ff_base':dict(memory='none',prior='original',loss='none'),
 'ff_dir':dict(memory='none',prior='original',loss='legacy'),
 'delay_base':dict(memory='none',prior='delay',loss='none'),
 'delay_dir':dict(memory='none',prior='delay',loss='legacy'),
 'recurrent_base':dict(memory='recurrent',prior='original',loss='none'),
 'recurrent_dir':dict(memory='recurrent',prior='original',loss='legacy'),
 'combined_base':dict(memory='recurrent',prior='delay',loss='none'),
 'combined_dir':dict(memory='recurrent',prior='delay',loss='legacy'),
 'capacity_mlp':dict(memory='none',prior='delay',loss='legacy',capacity=True),
 'capacity_gru':dict(memory='window',prior='delay',loss='legacy',capacity=True),
 'free_command':dict(memory='none',prior='free',loss='legacy'),
 'direction_only':dict(memory='none',prior='delay',loss='direction'),
 'norm_only':dict(memory='none',prior='delay',loss='norm'),
 'joint_calibration':dict(memory='none',prior='delay',loss='joint'),
 'paml_adaptation':dict(memory='none',prior='delay',loss='paml'),
 'vagram_adaptation':dict(memory='none',prior='delay',loss='vagram'),
}
def make_model(stats,name,seed,device,obs_dim=28):
 cfg=METHODS[name];seed_all(stream_seed(seed,'model_init'))
 width=160
 if cfg.get('capacity'):
  ref=ExecutionWorldModel(stats,obs_dim=obs_dim,width=160,memory='recurrent',prior='delay')
  width,_=capacity_matched_width(stats,ref.parameter_counts()['trainable'],obs_dim=obs_dim,memory=cfg['memory'])
 seed_all(stream_seed(seed,'model_init'))
 return ExecutionWorldModel(stats,obs_dim=obs_dim,width=width,memory=cfg['memory'],prior=cfg['prior']).to(device)
def train_critic(train,seed,device,updates=500):
 seed_all(stream_seed(seed,'critic'));obs=train['x'].shape[-1]
 critic=QCritic(obs,14).to(device);opt=torch.optim.Adam(critic.parameters(),lr=.001)
 gen=torch.Generator().manual_seed(stream_seed(seed,'critic_batch'));logs=[]
 # Monte-Carlo truncated returns from observed trajectory, no new simulator queries.
 target=sum(.99**k*train['r'][:,k] for k in range(train['r'].shape[1]))
 mean=target.mean().detach();scale=target.std().clamp_min(1e-6).detach()
 for it in range(updates):
  b=torch.randint(len(target),(128,),generator=gen).to(device)
  pred=critic(train['x'][b,0],train['a'][b,0]).reshape(-1)
  loss=((pred-(target[b]-mean)/scale)**2).mean();opt.zero_grad();loss.backward();opt.step()
  if it%100==0:logs.append({'update':it,'loss':loss.item()})
 for p in critic.parameters():p.requires_grad_(False)
 return critic,dict(training_updates=updates,target='observed H-step discounted Monte Carlo return, standardized on train only; no bootstrap',target_mean=mean.item(),target_scale=scale.item(),log=logs,parameter_count=sum(p.numel() for p in critic.parameters()))
def train_model(model,name,train,labels,seed,*,updates=1000,batch_size=64,horizon=8,critic=None,reward_fn=None,vision_policy=None):
 cfg=METHODS[name];dev=next(model.parameters()).device
 opt=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=.001)
 gen=torch.Generator().manual_seed(stream_seed(seed,'paired_batch'));logs=[]
 with measured(dev) as resource:
  for it in range(updates):
   idx=torch.randint(train['x'].shape[0],(batch_size,),generator=gen).to(dev)
   b={k:v[idx] for k,v in train.items()}
   h=model.burnin(b['xhist'],b['chist'],b['ahist'],detach=False) if model.memory!='none' else None
   y,u,hn=model.step(b['x'][:,0],b['c'][:,0],b['a'][:,0],b['fprev'][:,0],h)
   dyn=(((y-b['y'][:,0])/model.ystd)**2).mean();cmd=(((u-b['u'][:,0])/model.ustd)**2).mean();loss=dyn+cmd
   # Open-loop multi-step fitting, same scheduled loss for every architecture.
   if it%10==0:
    xx=b['x'][:,0];cc=b['c'][:,0];fp=b['fprev'][:,0];hh=h;multi=loss*0
    for k in range(horizon):
     xx,_,hh=model.step(xx,cc,b['a'][:,k],fp,hh)
     multi=multi+(((xx-b['y'][:,k])/model.ystd)**2).mean()/horizon
     cc,fp=observable_step(cc,b['a'][:,k],model.lower,model.upper,float(model.alpha))
    loss=loss+.1*multi
   extra=loss*0
   if cfg['loss'] in ('legacy','direction','norm','joint') and it%10==0:
    lab=labels[(it//10)%len(labels)];th=tensor(lab['theta'],model).clone().requires_grad_(True)
    J=imagined(model,th,lab['start'],horizon,reward_fn=reward_fn,vision_policy=vision_policy)
    g=torch.autograd.grad(J,th,create_graph=True)[0]
    extra=calibration_loss(g,tensor(lab['gradient'],model),tensor(lab['mask'],model),mode=cfg['loss'])
    loss=loss+.1*extra
   elif cfg['loss']=='paml' and it%10==0:
    th=torch.zeros(28,device=dev,requires_grad=True)
    next_c,_=observable_step(b['c'][:,0],b['a'][:,0],model.lower,model.upper,float(model.alpha))
    actor_fn=lambda state:actor(th,state,next_c[:,:14],b['refs'][:,1])
    extra=paml_loss(critic,actor_fn,b['y'][:,0],y,[th]);loss=loss+.1*extra
   elif cfg['loss']=='vagram':
    th=torch.zeros(28,device=dev)
    next_c,_=observable_step(b['c'][:,0],b['a'][:,0],model.lower,model.upper,float(model.alpha))
    value_fn=lambda state:critic(state,actor(th,state,next_c[:,:14],b['refs'][:,1]))
    extra=vagram_loss(value_fn,b['y'][:,0],y,state_scale=model.ystd);loss=loss+.1*extra
   if not torch.isfinite(loss):raise FloatingPointError(f'{name} nonfinite loss at {it}')
   opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
   if it%100==0 or it==updates-1:
    logs.append(dict(update=it+1,loss=loss.item(),dynamics_loss=dyn.item(),command_loss=cmd.item(),objective_loss=extra.item()))
    print(name,it+1,round(loss.item(),6),flush=True)
 return dict(log=logs,resource=resource,optimizer_state=opt.state_dict(),torch_rng=torch.get_rng_state(),batch_generator_state=gen.get_state(),batch_seed=stream_seed(seed,'paired_batch'),updates=updates)
def optimize(model,starts,horizon,updates=50,reward_fn=None,vision_policy=None):
 dev=next(model.parameters()).device;dim=28 if vision_policy is None else 32
 theta=torch.zeros(dim,device=dev,requires_grad=True);opt=torch.optim.Adam([theta],lr=.03);curves=[];traces={0:theta.detach().cpu().tolist()}
 with measured(dev) as resource:
  for it in range(updates):
   J=torch.stack([imagined(model,theta,s,horizon,reward_fn=reward_fn,vision_policy=vision_policy) for s in starts]).mean()
   opt.zero_grad();(-J).backward();opt.step()
   with torch.no_grad():theta.clamp_(-1,1)
   curves.append(float(J.detach()))
   if it+1 in (1,10,25,50,updates):traces[it+1]=theta.detach().cpu().tolist()
 return theta.detach().cpu().numpy(),dict(curve=curves,theta_traces=traces,resource=resource)
