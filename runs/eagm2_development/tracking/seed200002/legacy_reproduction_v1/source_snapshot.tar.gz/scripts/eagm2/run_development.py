"""Authorized development runner. Confirmation roots are hard-blocked."""
import os,sys
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import argparse,copy,time,traceback
import numpy as np,torch
from eagm2.runtime import *
from eagm2.data import make_env,collect,stats,sequences
from eagm2.training import METHODS,make_model,train_model,train_critic,optimize
from eagm2.gradients import finite_difference
from eagm2.rollout import physical
from eagm2.evaluation import model_metrics,evaluate_gradients,evaluate_returns

def make_labels(env,starts,seed,task,horizon,budget,kind,vision_policy=None):
 rng=np.random.default_rng(stream_seed(seed,kind));labels=[];dim=28 if vision_policy is None else 32
 for i,s in enumerate(starts):
  theta=np.zeros(dim) if i%2==0 else rng.normal(0,.3,dim).clip(-.8,.8)
  fd=finite_difference(lambda th:physical(env,th,s,horizon,budget,kind,task=task,vision_policy=vision_policy),theta)
  labels.append(dict(start=s,**fd));print(kind,i+1,'queries',fd['queries'],flush=True)
 return labels

def main():
 p=argparse.ArgumentParser();p.add_argument('--task',choices=['tracking','contact','vision'],required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--attempt',required=True);p.add_argument('--device',default='cuda');p.add_argument('--updates',type=int,default=1000);p.add_argument('--policy-updates',type=int,default=50);p.add_argument('--methods',default=','.join(METHODS));p.add_argument('--smoke',action='store_true');a=p.parse_args()
 check_seed(a.task,a.seed);seed_all(a.seed);out=new_run(a.task,a.seed,a.attempt);start=time.perf_counter();budget=Budget();env=None
 config=vars(a)|dict(phase='development_exploratory',confirmation_authorized=False,history=32,training_gradient_labels=12,diagnostic_gradient_labels=6,model_batch_size=64,selection='development only; no confirmatory interpretation')
 dump(out/'config.json',config);dump(out/'environment.json',environment());dump(out/'run_manifest.json',dict(status='running',config=config))
 try:
  if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA requested but unavailable; run host GPU authorized command; never silently label CPU as GPU')
  env=make_env(a.task);horizon=8 if a.task=='tracking' else 32
  data=collect(env,a.task,a.seed,budget,train_eps=3 if a.smoke else 18,val_eps=3 if a.smoke else 6,test_eps=3 if a.smoke else 30,length=96 if a.smoke else 160)
  torch.save(data,out/'dataset.pt');dump(out/'split_manifest.json',[dict(id=e['id'],split=e['split'],episode_seed=e['episode_seed'],delay=e['delay'],frames=len(e['x'])) for e in data['episodes']])
  reward_fn=None;vision_policy=None;vision_report=None
  if a.task=='contact':
   from eagm2.contact import TorchContactReward
   reward_fn=TorchContactReward(env).to(a.device).float()
  if a.task=='vision':
   from eagm2.visual_training import prepare_visual
   data,vision_policy,reward_fn,vision_report=prepare_visual(data,out,a.seed,a.device,smoke=a.smoke)
   dump(out/'vision_training.json',vision_report)
  statistic=stats(data);torch.save(statistic,out/'normalization.pt')
  tr=sequences(data,'train',horizon=horizon,device=a.device);val=sequences(data,'validation',horizon=horizon,device=a.device);te=sequences(data,'development_test',horizon=horizon,device=a.device)
  nlabel=2 if a.smoke else 12;ndiag=2 if a.smoke else 6
  labels=make_labels(env,data['starts']['train'][:nlabel],a.seed,a.task,horizon,budget,'labels_train',vision_policy)
  testlabs=make_labels(env,data['starts']['development_test'][:ndiag],a.seed,a.task,horizon,budget,'labels_diagnostic',vision_policy)
  torch.save(dict(train=labels,diagnostic=testlabs),out/'gradient_labels.pt')
  methods=a.methods.split(',');critic=None;critic_report=None
  if any(METHODS[m]['loss'] in ('paml','vagram') for m in methods):
   with measured(a.device) as cres:critic,critic_report=train_critic(tr,a.seed,a.device,updates=50 if a.smoke else 500)
   critic_report['resource']=cres;dump(out/'critic_training.json',critic_report);torch.save(critic.state_dict(),out/'checkpoints/critic.pt')
  eval_h=16 if a.task=='tracking' else max(1,int(np.ceil(10/env.control_dt))-32)
  dim=28 if vision_policy is None else 32
  initial=evaluate_returns(env,np.zeros(dim),data['starts']['development_test'],eval_h,budget,a.task,vision_policy=vision_policy)
  dump(out/'initial_policy.json',initial);status=[]
  for name in methods:
   mbegin=time.perf_counter();model=make_model(statistic,name,a.seed,a.device,obs_dim=tr['x'].shape[-1])
   count=model.parameter_counts();kwargs=dict(reward_fn=reward_fn,vision_policy=vision_policy)
   train_report=train_model(model,name,tr,labels,a.seed,updates=a.updates,batch_size=16 if a.smoke else 64,horizon=horizon,critic=critic,**kwargs)
   torch.save(dict(state_dict=model.state_dict(),stats=statistic,method=name,model_config=dict(obs_dim=model.obs_dim,width=model.width,memory=model.memory,prior=model.prior),optimizer=train_report.pop('optimizer_state'),torch_rng=train_report.pop('torch_rng'),batch_generator_state=train_report.pop('batch_generator_state'),seed=a.seed),out/'checkpoints'/f'{name}.pt')
   dump(out/'training_logs'/f'{name}.json',train_report)
   grad=evaluate_gradients(model,testlabs,horizon,**kwargs)
   theta,pol=optimize(model,data['starts']['train'][:2 if a.smoke else 6],horizon,updates=a.policy_updates,**kwargs)
   result=dict(status='completed',phase='exploratory',method=name,seed=a.seed,parameter_counts=count,training=train_report,model_metrics=model_metrics(model,te,horizon),validation_model_metrics=model_metrics(model,val,horizon),gradient=grad,policy_optimization=pol,theta_final=theta,physical=evaluate_returns(env,theta,data['starts']['development_test'],eval_h,budget,a.task,vision_policy=vision_policy),wall_seconds=time.perf_counter()-mbegin,critic_adaptation=critic_report if METHODS[name]['loss'] in ('paml','vagram') else None)
   result['delta_return_vs_initial']=result['physical']['mean_return']-initial['mean_return']
   dump(out/name/'results.json',result);status.append(dict(method=name,status='completed',wall_seconds=result['wall_seconds']))
   dump(out/'experiment_status.json',status);dump(out/'budget.json',budget.as_dict())
   print('COMPLETED',name,'return',result['physical']['mean_return'],'cos',grad['mean_cosine'],flush=True)
  dump(out/'results.json',dict(status='completed',phase='exploratory',task=a.task,seed=a.seed,methods=status,wall_seconds=time.perf_counter()-start,budget=budget.as_dict(),confirmation_authorized=False))
  dump(out/'run_manifest.json',dict(status='completed',config=config,wall_seconds=time.perf_counter()-start))
 except Exception:
  dump(out/'failure.json',dict(traceback=traceback.format_exc(),wall_seconds=time.perf_counter()-start,budget=budget.as_dict()));dump(out/'run_manifest.json',dict(status='failed',config=config));raise
 finally:
  if env is not None and hasattr(env,'close'):env.close()
if __name__=='__main__':main()
